import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { generateEmailSuggestion } from "@/lib/ai"

export async function POST(request: NextRequest) {
  try {
    const { contactId, context, purpose } = await request.json()

    // Get authenticated user
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Fetch contact and company data
    const { data: contact } = await supabase
      .from("contacts")
      .select(`
        *,
        companies (*)
      `)
      .eq("id", contactId)
      .single()

    if (!contact) {
      return NextResponse.json({ error: "Contact not found" }, { status: 404 })
    }

    const email = await generateEmailSuggestion(contact, contact.companies, context, purpose)

    return NextResponse.json({ email })
  } catch (error) {
    console.error("Email generation error:", error)
    return NextResponse.json({ error: "Email generation failed" }, { status: 500 })
  }
}
