"use server"

import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import bcrypt from "bcryptjs"

const getSupabaseClient = () => {
  const cookieStore = cookies()
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value
      },
      set(name: string, value: string, options: any) {
        cookieStore.set({ name, value, ...options })
      },
      remove(name: string, options: any) {
        cookieStore.set({ name, value: "", ...options })
      },
    },
  })
}

const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

// Sign in action
export async function signIn(prevState: any, formData: FormData) {
  if (!formData) {
    console.log("[v0] Form data is missing")
    return { error: "Form data is missing" }
  }

  const email = formData.get("email")
  const password = formData.get("password")

  if (!email || !password) {
    console.log("[v0] Email or password missing")
    return { error: "Email and password are required" }
  }

  try {
    console.log("[v0] Attempting login for:", email)
    const supabase = getSupabaseClient()

    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.toString(),
      password: password.toString(),
    })

    console.log("[v0] Auth response:", { data: !!data.user, error: error?.message })

    if (error) {
      console.log("[v0] Auth error:", error.message)
      return { error: "Invalid login credentials" }
    }

    if (!data.user) {
      console.log("[v0] No user returned from auth")
      return { error: "Invalid login credentials" }
    }

    console.log("[v0] Checking profile for user:", data.user.id)
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("status, role")
      .eq("id", data.user.id)
      .single()

    console.log("[v0] Profile data:", profile, "Profile error:", profileError?.message)

    if (profileError || !profile) {
      console.log("[v0] Profile not found or error")
      await supabase.auth.signOut()
      return { error: "Your account is not approved or does not exist." }
    }

    if (profile.status !== "approved") {
      console.log("[v0] Profile not approved, status:", profile.status)
      await supabase.auth.signOut()
      return { error: "Your account is not approved or does not exist." }
    }

    console.log("[v0] Login successful for user with role:", profile.role)
    redirect("/dashboard")
  } catch (error) {
    console.error("[v0] Login error:", error)
    return { error: "Invalid login credentials" }
  }
}

// Sign up action
export async function signUp(prevState: any, formData: FormData) {
  // Check if formData is valid
  if (!formData) {
    return { error: "Form data is missing" }
  }

  const email = formData.get("email")
  const password = formData.get("password")
  const fullName = formData.get("fullName")

  // Validate required fields
  if (!email || !password || !fullName) {
    return { error: "Email, password, and full name are required" }
  }

  try {
    const { data: existingPending } = await supabaseAdmin
      .from("pending_users")
      .select("id")
      .eq("email", email.toString())
      .single()

    if (existingPending) {
      return { error: "A signup request with this email is already pending approval." }
    }

    const { data: existingProfile } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("email", email.toString())
      .single()

    if (existingProfile) {
      return { error: "An account with this email already exists." }
    }

    const hashedPassword = await bcrypt.hash(password.toString(), 10)

    const { error: pendingError } = await supabaseAdmin.from("pending_users").insert([
      {
        email: email.toString(),
        full_name: fullName.toString(),
        encrypted_password: hashedPassword,
        requested_role: "sales_agent",
        status: "pending",
      },
    ])

    if (pendingError) {
      console.error("Pending user creation error:", pendingError)
      return { error: "Failed to submit signup request. Please try again." }
    }

    return {
      success: "Your signup request has been submitted. An administrator will review and approve your account shortly.",
    }
  } catch (error) {
    console.error("Sign up error:", error)
    return { error: "An unexpected error occurred. Please try again." }
  }
}

// Sign out action
export async function signOut() {
  const cookieStore = cookies()
  const supabase = getSupabaseClient()

  await supabase.auth.signOut()
  redirect("/auth/login")
}
